package login.upeu.edu.pe.login;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface RepositoryUsuario extends CrudRepository<ModelUsuario, Integer> {
		 @Query(value = "SELECT * FROM model_usuario WHERE usuario = ?1 and password = ?2", 
		    nativeQuery = true)
		  ModelUsuario findByUser(String user, String pass);
}