package login.upeu.edu.pe.login;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestControllerUsuario { 
	@Autowired 
	private RepositoryUsuario userRepository;
	@GetMapping(path="/login/{user}/{pass}")
	 ModelUsuario getUsuario(@PathVariable String user,@PathVariable String pass) {
	    // This returns a JSON or XML with the users
	    return userRepository.findByUser( user, pass);
	}
	@PostMapping("/save")
	ModelUsuario newUsuario(@RequestBody ModelUsuario modelUsuario) {
	    return userRepository.save(modelUsuario);
	}
}
